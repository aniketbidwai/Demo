//
//  Recurrence.swift
//  EventListDemo
//
//  Created by Aniket Bidwai on 10/05/16.
//  Copyright © 2016 Aniket Bidwai. All rights reserved.
//

import Foundation

class Recurrence: NSObject {

}
