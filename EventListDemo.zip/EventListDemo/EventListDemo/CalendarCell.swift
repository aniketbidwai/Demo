//
//  CalendarCell.swift
//  EventListDemo
//
//  Created by Aniket Bidwai on 11/05/16.
//  Copyright © 2016 Aniket Bidwai. All rights reserved.
//

import UIKit

class CalendarCell: UICollectionViewCell {
    var date: NSDate?
    @IBOutlet var lblTitle: UILabel!
    
    override var selected: Bool{
        didSet{
            self.selected ? selectCell() : deselectCell()
        }
    }
    
    func selectedWithBackgroundColor(color: UIColor) {
        self.lblTitle.layer.cornerRadius = self.lblTitle.frame.size.width/2
        self.lblTitle.layer.backgroundColor = color.CGColor
        self.lblTitle.textColor = UIColor.whiteColor()
    }
    
    func deSelectedWithTextColor(color: UIColor) {
        self.lblTitle.layer.backgroundColor = UIColor.clearColor().CGColor
        self.lblTitle.textColor = color
    }
    
    func selectCell(){
        selectedWithBackgroundColor(Constants.calenderCellSelectionColor)
    }
    
    func deselectCell(){
        deSelectedWithTextColor(Constants.calenderCellTextColor)
    }
    
    func setTodayCellColor(backgroundColor: UIColor) {
        self.lblTitle.layer.cornerRadius = self.lblTitle.frame.size.width/2
        self.lblTitle.layer.backgroundColor = backgroundColor.CGColor
        self.lblTitle.textColor  = UIColor.whiteColor()
    }
}
