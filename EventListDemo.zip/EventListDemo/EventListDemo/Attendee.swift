//
//  Attendee.swift
//  EventListDemo
//
//  Created by Aniket Bidwai on 10/05/16.
//  Copyright © 2016 Aniket Bidwai. All rights reserved.
//

import Foundation

class Attendee: NSObject {
    var email:String?
    var name:String?
    var status:AttendeeStatus = .AttendeeStatus_Not_Responded
    var type:AttendeeType = .AttendeeType_Required
}
