//
//  Event.swift
//  EventListDemo
//
//  Created by Aniket Bidwai on 10/05/16.
//  Copyright © 2016 Aniket Bidwai. All rights reserved.
//

import Foundation
class Event: NSObject {
    var eventID:String?
    var originalEventID:String?
    var folderID:String?
    var subject:String?
    var categoryIDs:String?
    var primaryCategory:String?
    var body:String?
    var bodyType:BodyType = .BodyType_Unknown
    var organizerName:String?
    var organizerEmail:String?
    
    var isAllDay = false
    var isBodyTruncated = false
    var responseRequested = false
    var disallowNewTimeProposal = false
    
    var busyStatus:BusyStatus = .BusyStatus_Free
    var timeZone : NSTimeZone?
    var creationTime:NSDate?; //DtStamp
    var startTime:NSDate?
    var endTime:NSDate?
    var appointmentReplyTime:NSDate?
    var reminderMinutes:UInt = 0
    var sensitivity:Sensitivity = .Sensitivity_Normal
    var location:String?
    var meetingStatus:MeetingStatus = .MeetingStatus_Appoinment
    var Attendees = [Attendee]()
    var recurrence:Recurrence?
    var responseType:ResponseType = .ResponseType_Unknown
    var onlineMeetingExternalLink:String?
}
