//
//  Constants.swift
//  EventListDemo
//
//  Created by Aniket Bidwai on 10/05/16.
//  Copyright © 2016 Aniket Bidwai. All rights reserved.
//

import Foundation
import UIKit

enum BusyStatus:Int {
    case BusyStatus_Free = 0,
    BusyStatus_Tentative,
    BusyStatus_Busy,
    BusyStatus_Out_of_Office,
    BusyStatus_Working_elsewhere
}


enum MeetingStatus:Int{
    case MeetingStatus_Appoinment                    = 0
    case MeetingStatus_Meeting_As_Organisar          = 1
    case MeetingStatus_Meeting_As_Attendee           = 3
    case MeetingStatus_Canceled_As_Organisar         = 5
    case MeetingStatus_Canceled_As_Attendee          = 7
    case MeetingStatus_Meeting_As_Organisar1         = 9
    case MeetingStatus_Meeting_As_Attendee1          = 11
    case MeetingStatus_Canceled_As_Organisar1        = 13
    case MeetingStatus_Canceled_As_Attendee1         = 15
}

enum AttendeeStatus:Int{
    case AttendeeStatus_Unknown = 0
    case AttendeeStatus_Tentative = 2,
    AttendeeStatus_Accept,
    AttendeeStatus_Decline,
    AttendeeStatus_Not_Responded
}

enum ResponseType:Int{
    case ResponseType_Unknown = 0,
    ResponseType_Organizer,
    ResponseType_Tentative,
    ResponseType_Accept,
    ResponseType_Decline,
    ResponseType_Not_Responded
}

enum AttendeeType:Int{
    case AttendeeType_Required = 1,
    AttendeeType_Optional,
    AttendeeType_Resource
}
enum BodyType:Int{
    case BodyType_Unknown = 0,
    BodyType_PlainText,
    BodyType_HTML,
    BodyType_RTF,
    BodyType_MIME
}

enum Sensitivity:Int{
    case Sensitivity_Normal = 0,
    Sensitivity_Personal,
    Sensitivity_Private,
    Sensitivity_Confidential
}


struct Constants {
    static let Days_In_Week = 7
    static let calenderCellSelectionColor = UIColor(red: (52/255), green: (152/255), blue: (219/255), alpha: 1.0)
    static let calenderCellTextColor = UIColor.lightGrayColor()
}