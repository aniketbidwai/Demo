//
//  ViewController.swift
//  EventListDemo
//
//  Created by Aniket Bidwai on 10/05/16.
//  Copyright © 2016 Aniket Bidwai. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

