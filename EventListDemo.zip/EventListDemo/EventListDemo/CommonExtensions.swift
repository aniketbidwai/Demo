//
//  CommonExtensions.swift
//  EventListDemo
//
//  Created by Aniket Bidwai on 10/05/16.
//  Copyright © 2016 Aniket Bidwai. All rights reserved.
//

import Foundation
extension NSDate{
    
    //Method to get string from date with specific format
    //Param : when format is nil, date is formated with default format i.e. "EEEE,MMMM dd"
    func string(format:String?)->String?{
        let dateFormater = NSDateFormatter();
        let LocString = NSDateFormatter.dateFormatFromTemplate((format != nil ? format! : "EEEE,MMMM dd"), options: 0, locale: NSLocale.currentLocale())
        
        dateFormater.dateFormat = LocString
        return dateFormater.stringFromDate(self)
    }
    
    //Method to add number of days to current date
    func addDays(days:Int) -> NSDate {
        let secInDays = 60 * 60 * 24 * Double(days)
        return self.dateByAddingTimeInterval(secInDays)
    }
    
    //Method to check if current date is before other date
    func isBefore(date:NSDate!) -> Bool {
        return self.compare(date) == .OrderedAscending
    }
    
    //Method to check if current date is ater other date
    func isAfter(date:NSDate!) -> Bool {
        return self.compare(date) == .OrderedDescending
    }
}
