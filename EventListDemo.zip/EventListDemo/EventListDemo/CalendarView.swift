//
//  CalendarView.swift
//  EventListDemo
//
//  Created by Aniket Bidwai on 11/05/16.
//  Copyright © 2016 Aniket Bidwai. All rights reserved.
//

import UIKit

let kCellReuseIdentifier = "CalendarCell"
let kFirst_Day_Index = 0
let kNumber_Of_Days_Index = 1

//MARK: - CalendarViewDataSource declaration
@objc protocol CalendarViewDataSource{
    func startDateForCalendar(calendar: CalendarView) -> NSDate?
    func endDateForCalendar(calendar: CalendarView) -> NSDate?
    
}
//MARK: - CalendarViewDelegate declaration
@objc protocol CalendarViewDelegate{
    optional func calendar(calendar: CalendarView, canSelectDate date : NSDate) -> Bool
    optional func calendar(calendar: CalendarView, didSelectDate date : NSDate) -> Void
    optional func calendar(calendar: CalendarView, didDeselectDate date : NSDate) -> Void
}

class CalendarView: UIView {
    
    weak var dataSource : CalendarViewDataSource?
    weak var delegate   : CalendarViewDelegate?
    
    @IBOutlet var calendarView: UICollectionView!
    
    var monthInfo = [Int:[Int]]()
    
    private var startDateCache = NSDate()
    private var endDateCache = NSDate()
    private var startOfMonthCache = NSDate()
    
    private var todayIndexPath: NSIndexPath?
    private(set) var selectedIndexPath: NSIndexPath?
    private(set) var selectedDate: NSDate?
    
    private lazy var gregorian : NSCalendar = {
        let cal = NSCalendar(identifier: NSCalendarIdentifierGregorian)!
        cal.timeZone = NSTimeZone(abbreviation: "UTC")!
        return cal
    }()
    
    //Method to get gregorian calender
    var calendar : NSCalendar {
        return self.gregorian
    }
    
    //Method to reload and render the calender view
    func reloadData() {
        self.calendarView.reloadData()
    }
    
    func selectDate(date : NSDate) {
        guard let indexPath = self.indexPathForDate(date) else {
            return
        }
        
        guard self.calendarView.indexPathsForSelectedItems()?.contains(indexPath) == false else {
            return
        }
        
        if selectedIndexPath != nil {
            self.calendarView.deselectItemAtIndexPath(selectedIndexPath!, animated: false)
        }
        
        self.calendarView.selectItemAtIndexPath(indexPath, animated: true, scrollPosition: .Top)
        selectedIndexPath = indexPath
        selectedDate = date
    }
    
    func deselectDate(date : NSDate) {
        guard let indexPath = self.indexPathForDate(date) else {
            return
        }
        
        guard self.calendarView.indexPathsForSelectedItems()?.contains(indexPath) == true else {
            return
        }
        
        self.calendarView.deselectItemAtIndexPath(indexPath, animated: false)
        selectedIndexPath = nil
        selectedDate = nil
    }
    
    func indexPathForDate(date : NSDate) -> NSIndexPath? {
        let distanceFromStartComponent = gregorian.components( [.Month, .Day], fromDate:startOfMonthCache, toDate: date, options: NSCalendarOptions() )
        
        guard let currentMonthInfo : [Int] = monthInfo[distanceFromStartComponent.month] else {
            return nil
        }
        
        let item = distanceFromStartComponent.day + currentMonthInfo[kFirst_Day_Index]
        let indexPath = NSIndexPath(forItem: item, inSection: distanceFromStartComponent.month)
        
        return indexPath
    }
}

extension CalendarView: UICollectionViewDelegate,UICollectionViewDataSource {
    //MARK: - UICollectionViewDataSource Methods
    
    func numberOfSectionsInCollectionView(collectionView: UICollectionView) -> Int {
        guard let startDate = self.dataSource?.startDateForCalendar(self), endDate = self.dataSource?.endDateForCalendar(self) else {
            print("Data source not available")
            return 0
        }
        
        startDateCache = startDate
        endDateCache = endDate
        
        // check if the dates are in correct order
        if gregorian.compareDate(startDate, toDate: endDate, toUnitGranularity: .Nanosecond) != NSComparisonResult.OrderedAscending {
            print("Invalide startDate and endDate Range.")
            return 0
        }
        
        let firstDayOfStartMonth = gregorian.components([.Era, .Year, .Month], fromDate: startDateCache)
        firstDayOfStartMonth.day = 1
        
        guard let startOfMonth = gregorian.dateFromComponents(firstDayOfStartMonth) else {
            return 0
        }
        
        startOfMonthCache = startOfMonth
        
        let today = NSDate()
        
        if  startOfMonthCache.compare(today) == .OrderedAscending && endDateCache.compare(today) == .OrderedDescending {
            let differenceFromTodayComponents = gregorian.components([.Month, .Day], fromDate:startOfMonthCache, toDate:today, options: NSCalendarOptions())
            
            todayIndexPath = NSIndexPath(forItem: differenceFromTodayComponents.day, inSection: differenceFromTodayComponents.month)
        }
        
        let differenceComponents = gregorian.components(.Month, fromDate: startDateCache, toDate: endDateCache, options: NSCalendarOptions())
        
        return differenceComponents.month == 0 ?  1 : differenceComponents.month
    }
    
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        let monthOffsetComponents = NSDateComponents()
        monthOffsetComponents.month = section; //section as month index
        
        guard let correctMonthForSectionDate = gregorian.dateByAddingComponents(monthOffsetComponents, toDate: startOfMonthCache, options: NSCalendarOptions()) else {
            return 0
        }
        
        // Determine month first day index and number of days in month
        let numberOfDays = gregorian.rangeOfUnit(.Day, inUnit:.Month, forDate:correctMonthForSectionDate).length
        var firstWeekdayIndex = self.gregorian.component(.Weekday, fromDate:correctMonthForSectionDate)
        firstWeekdayIndex = (firstWeekdayIndex + 6) % Constants.Days_In_Week
        
        monthInfo[section] = [firstWeekdayIndex, numberOfDays]
        
        return (firstWeekdayIndex + numberOfDays)
    }
    
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        let dayCell = collectionView.dequeueReusableCellWithReuseIdentifier(kCellReuseIdentifier, forIndexPath: indexPath) as! CalendarCell
        
        let currentMonthInfo = monthInfo[indexPath.section]!
        let firstDayInMonth = currentMonthInfo[kFirst_Day_Index]
        let nDays = currentMonthInfo[kNumber_Of_Days_Index]
        
        if indexPath.item >= firstDayInMonth && indexPath.item < firstDayInMonth + nDays {
            
            let fromStartOfMonthIndexPath = NSIndexPath(forItem: indexPath.item - firstDayInMonth, inSection: indexPath.section)
            
            let offsetComponents = NSDateComponents()
            offsetComponents.month = indexPath.section
            offsetComponents.day = indexPath.item - firstDayInMonth
            
            dayCell.date =  gregorian.dateByAddingComponents(offsetComponents, toDate: startOfMonthCache, options: NSCalendarOptions())
            
            print("dayCell.date: \(dayCell.date!)")
            dayCell.lblTitle.text = String(fromStartOfMonthIndexPath.item + 1)
            dayCell.hidden = false
        }
        else {
            dayCell.date = nil
            dayCell.lblTitle.text = ""
            dayCell.hidden = true
        }
        
        dayCell.selected = (selectedIndexPath != nil && indexPath == selectedIndexPath)
        
        return dayCell
    }
    //MARK: - UICollectionViewDelegate Methods
    func collectionView(collectionView: UICollectionView, shouldSelectItemAtIndexPath indexPath: NSIndexPath) -> Bool {
        guard let dayCell = collectionView.cellForItemAtIndexPath(indexPath) as? CalendarCell else { return  false}
        
        // Return false when date is invalid
        guard dayCell.date != nil else { return false }
        
        if let canSelectFromDelegate = delegate?.calendar?(self, canSelectDate: dayCell.date!) {
            return canSelectFromDelegate
        }
        
        return true // select any date by default
    }
    
    
    func collectionView(collectionView: UICollectionView, didSelectItemAtIndexPath indexPath: NSIndexPath) {
        guard let dayCell = collectionView.cellForItemAtIndexPath(indexPath) as? CalendarCell else { return }
        
        guard dayCell.date != nil else { return }
        
        dayCell.selected = true
        delegate?.calendar!(self, didSelectDate: dayCell.date!)
        selectedIndexPath = indexPath
        selectedDate = dayCell.date
    }
    
    func collectionView(collectionView: UICollectionView, didDeselectItemAtIndexPath indexPath: NSIndexPath) {
        guard let dayCell = collectionView.cellForItemAtIndexPath(indexPath) as? CalendarCell else { return }
        
        guard dayCell.date != nil else { return }
        
        dayCell.selected = false
        delegate?.calendar?(self, didDeselectDate: dayCell.date!)
        selectedIndexPath = nil
        selectedDate = nil
    }
}
