//
//  AddEventController.swift
//  EventListDemo
//
//  Created by Aniket Bidwai on 12/05/16.
//  Copyright © 2016 Aniket Bidwai. All rights reserved.
//

import UIKit

class AddEventController: UIViewController {

    @IBAction func cancelAction(sender: AnyObject) {
        self.performSegueWithIdentifier("unwindNewEvent", sender: self)

    }
}
