//
//  CalendarLayout.swift
//  EventListDemo
//
//  Created by Aniket Bidwai on 11/05/16.
//  Copyright © 2016 Aniket Bidwai. All rights reserved.
//

import UIKit

class CalendarLayout: UICollectionViewFlowLayout {
    
    
    //let itemHeight: CGFloat = 44
    
    override init() {
        super.init()
        setupLayout()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setupLayout()
    }
    
    func setupLayout() {
        minimumInteritemSpacing = 7.0
        minimumLineSpacing = 5
        scrollDirection = .Vertical
        itemSize = CGSizeMake(40, 40)
        sectionInset = UIEdgeInsets(top: 5, left: 5, bottom: 5, right: 5)
    }
    
    
    func collectionViewWidth(forBounds bounds:CGRect) -> CGFloat {
        
        let contentInsets = self.collectionView!.contentInset
        
        return (bounds.width - sectionInset.left - sectionInset.right - contentInsets.left - contentInsets.right)
    }
    
    override func prepareLayout() {
        let spaceWidth = collectionViewWidth(forBounds: collectionView!.bounds) - (itemSize.width * 7)
        minimumInteritemSpacing = spaceWidth/6.0
        super.prepareLayout()
    }
    
    override func shouldInvalidateLayoutForBoundsChange(newBounds: CGRect) -> Bool {
        if !CGSizeEqualToSize(newBounds.size, collectionView!.bounds.size) {
            let spaceWidth = collectionViewWidth(forBounds: newBounds) - (itemSize.width * 7)
            minimumInteritemSpacing = spaceWidth/6.0
            return true
        }
        return false
    }
    
    override func targetContentOffsetForProposedContentOffset(proposedContentOffset: CGPoint) -> CGPoint {
        return collectionView!.contentOffset
    }
    
    
    /*override func layoutAttributesForSupplementaryViewOfKind(elementKind: String, atIndexPath indexPath: NSIndexPath) -> UICollectionViewLayoutAttributes? {
     let attribute = UICollectionViewLayoutAttributes(forSupplementaryViewOfKind: elementKind, withIndexPath: indexPath)
     attribute.frame = CGRect(x: 0, y: 0, width: collectionViewWidth(forBounds: collectionView!.bounds), height: 50)
     return attribute
     }*/
}
