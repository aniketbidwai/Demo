//
//  EventTableCell.swift
//  EventListDemo
//
//  Created by Aniket Bidwai on 10/05/16.
//  Copyright © 2016 Aniket Bidwai. All rights reserved.
//

import UIKit

class EventTableCell: UITableViewCell {

    @IBOutlet var lblLocationBottom: NSLayoutConstraint!
    @IBOutlet var lblStartTime: UILabel!
    @IBOutlet var lblEndTime: UILabel!
    @IBOutlet var lblAllDay: UILabel!
    @IBOutlet private var imgSubjectIcon: UIImageView!
    @IBOutlet var lblEventSubject: UILabel!
    @IBOutlet private var imgAvtar1: UIImageView!
    @IBOutlet private var imgAvtar2: UIImageView!
    @IBOutlet private var imgAvtar3: UIImageView!
    @IBOutlet private var imgAvtar4: UIImageView!
    @IBOutlet private var imgLocationIcon: UIImageView!
    @IBOutlet private var lblLocation: UILabel!
    @IBOutlet private var imgAvtar1Height: NSLayoutConstraint!
    @IBOutlet private var lblLocationHeight: NSLayoutConstraint!
    
    func setLocation(location:String?)  {
        lblLocation.text = location
        guard location?.characters.count > 0 else {
            imgLocationIcon.image = nil
            lblLocationHeight.constant = 0
            return
        }
        imgLocationIcon.image = UIImage(named: "Location")
        lblLocationHeight.constant = 15
    }
    func setAttendees(attendees:[Attendee]?) {
        guard attendees?.count > 0 else {
            imgAvtar1.image = nil
            imgAvtar1Height.constant = 0
            return
        }
        
        imgAvtar1.image = UIImage(named: "Avatar-3")
        imgAvtar1Height.constant = 44
        
    }
    
}
