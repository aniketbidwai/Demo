//
//  EventTableCell.swift
//  EventListDemo
//
//  Created by Aniket Bidwai on 10/05/16.
//  Copyright © 2016 Aniket Bidwai. All rights reserved.
//

import UIKit

class EventTableCell: UITableViewCell {

    @IBOutlet var lblStartTime: UILabel!
    @IBOutlet var lblEndTime: UILabel!
    @IBOutlet var lblAllDay: UILabel!
    @IBOutlet var imgSubjectIcon: UIImageView!
    @IBOutlet var lblEventSubject: UILabel!
    @IBOutlet var imgAvtar1: UIImageView!
    @IBOutlet var imgAvtar2: UIImageView!
    @IBOutlet var imgAvtar3: UIImageView!
    @IBOutlet var imgAvtar4: UIImageView!
    @IBOutlet var imgLocationIcon: UIImageView!
    @IBOutlet var lblLocation: UILabel!
}
