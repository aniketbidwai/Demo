//
//  CalendarHeader.swift
//  EventListDemo
//
//  Created by Aniket Bidwai on 11/05/16.
//  Copyright © 2016 Aniket Bidwai. All rights reserved.
//

import UIKit

class CalendarHeader: UIView {
    
    override func awakeFromNib() {
        // Add Weekday labels to header view
        let formatter : NSDateFormatter = NSDateFormatter()
        for index in 0...6 {
            let day : NSString = formatter.weekdaySymbols[index] as NSString
            let dayLabel = UILabel()
            dayLabel.font = UIFont(name: "Helvetica", size: 14.0)
            dayLabel.text = day.substringToIndex(1).uppercaseString
            dayLabel.textColor = UIColor.blackColor()
            dayLabel.backgroundColor = UIColor.clearColor()
            dayLabel.textAlignment = .Center
            self.addSubview(dayLabel)
        }
    }
    
    override func layoutSubviews() {
        
        super.layoutSubviews()
        //Update weekday label position according to header view layout. 
        var labelFrame = CGRect(x: 0.0, y:0.0, width: self.bounds.size.width / 7.0, height: self.bounds.size.height)
        for lbl in self.subviews {
            lbl.frame = labelFrame
            labelFrame.origin.x += labelFrame.size.width
        }
    }
}
