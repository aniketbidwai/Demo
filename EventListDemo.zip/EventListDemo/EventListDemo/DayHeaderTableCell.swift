//
//  DayHeaderTableCell.swift
//  EventListDemo
//
//  Created by Aniket Bidwai on 10/05/16.
//  Copyright © 2016 Aniket Bidwai. All rights reserved.
//

import UIKit

class DayHeaderTableCell: UITableViewCell {
    @IBOutlet var lblTitle: UILabel!
    @IBOutlet var lblTemp: UILabel!
    @IBOutlet var imgTempIcon: UIImageView!

    func setTemperature(value:String?)  {
        guard value!.characters.count > 0 else {
            lblTemp.hidden = true
            imgTempIcon.hidden = true
            return
        }
        
        lblTemp.text = value!
        lblTemp.hidden = false
        
        //imgTempIcon.image = UIImage()
        imgTempIcon.hidden = false
        
    }
}
