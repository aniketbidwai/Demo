//
//  EventsController.swift
//  EventListDemo
//
//  Created by Aniket Bidwai on 10/05/16.
//  Copyright © 2016 Aniket Bidwai. All rights reserved.
//

import UIKit

class EventsController: UIViewController {
    
    // Outlet Reference to Events TableView
    @IBOutlet var calendarView: CalendarView!
    @IBOutlet var listView: UITableView!
    var listViewInitiatedScroll = false
    var events = [Event]?(){
        didSet{
            
        }
    }
    lazy var gregorian : NSCalendar = {
        
        let cal = NSCalendar(identifier: NSCalendarIdentifierGregorian)!
        
        cal.timeZone = NSTimeZone(abbreviation: "UTC")!
        
        return cal
    }()
    var eventsByIndexPath = [NSDate:[Event]]()
    var dates:[NSDate]?
    var todayIndexPath: NSIndexPath?
    
    func configureListView() {
        listView.rowHeight = UITableViewAutomaticDimension
        listView.estimatedRowHeight = 34
    }
    
    func datesWithCalendarUnit(unit:NSCalendarUnit, withDate date:NSDate!) -> [NSDate:[Event]] {
        var beginning:NSDate?
        var length:NSTimeInterval = 0
        self.gregorian.rangeOfUnit(unit, startDate: &beginning, interval: &length, forDate: date)
        let end = beginning!.dateByAddingTimeInterval(length-1)
        return datesFromDate(beginning!, toDate: end)
    }
    
    //Method to calculate dates between fromDate and endDate and return dictionary populated with all intermediate dates as key
    func datesFromDate(fromDate:NSDate!, toDate:NSDate!) -> [NSDate:[Event]] {
        assert(fromDate.compare(toDate) == .OrderedAscending,"toDate must be after fromDate")
        let days = NSDateComponents()
        var eventsDictionary = [NSDate:[Event]]()
        var dayCount = 0;
        while(true){
            days.day = dayCount
            dayCount += 1
            let nextDate =  gregorian.dateByAddingComponents(days, toDate: fromDate, options: .MatchLast)
            if(nextDate!.compare(toDate) == .OrderedDescending){  break; }
            
            var events = [Event]()
            let rowCnt = Int(arc4random_uniform(10))
            for i in 0...rowCnt {
                let eventItem = Event()
                if i == Int(arc4random_uniform(UInt32(rowCnt))) {
                    eventItem.subject = "asdfasdfsfsadf"
                }
                events.append(eventItem)
            }
            eventsDictionary[nextDate!] = events
        }
        
        return eventsDictionary
    }
    
    //Method to populate all dates for current year
    func loadCurrentYear() {
        let temp = datesWithCalendarUnit(.Year, withDate: NSDate())
        var allKeys = [NSDate](temp.keys)
        allKeys.sortInPlace { $0.compare($1) == .OrderedAscending }
        
        let lockQueue = dispatch_queue_create("com.demo.lock", nil)
        dispatch_sync(lockQueue) {
            self.dates = allKeys
            self.eventsByIndexPath = temp
        }
        
        listView.reloadData()
        
        let now = gregorian.startOfDayForDate( NSDate())
        let section = allKeys.indexOf(now)
        if section != nil && todayIndexPath == nil{
            todayIndexPath = NSIndexPath(forRow:NSNotFound, inSection: section!)
        }
        
        if todayIndexPath != nil {
            listView.scrollToRowAtIndexPath(todayIndexPath!, atScrollPosition: .Top, animated: true)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        calendarView!.dataSource = self
        calendarView!.delegate = self
        configureListView()
        loadCurrentYear()
        calendarView!.selectDate(NSDate())
    }
    
    //Method to unwind NewEvent segue
    @IBAction func unwindNewEvent(segue: UIStoryboardSegue){
        
    }
}

extension EventsController:UITableViewDelegate, UITableViewDataSource, UIScrollViewDelegate{
    
    //MARK: - UITableViewDataSource Methods
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return  dates != nil ? dates!.count : 0 //eventsByIndexPath.keys.count
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let rowCnt = eventsByIndexPath[dates![section]]!.count
        return rowCnt == 0 ? 1 : rowCnt
    }
    
    
    func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView = UIView(frame: CGRect(x: 0, y: 0, width: CGRectGetWidth(tableView.bounds), height: 25))
        headerView.backgroundColor = UIColor.groupTableViewBackgroundColor()
        headerView.autoresizingMask = [.FlexibleWidth, .FlexibleHeight]
        
        let sectionDate = dates![section]
        var prefix = ""
        var now = gregorian.startOfDayForDate(NSDate())
        if sectionDate.compare(now) == .OrderedSame {
            prefix = "Today・"
        }else{
            now = gregorian.startOfDayForDate(now.addDays(1))
            if sectionDate.compare(now) == .OrderedSame {
                prefix = "Tomorrow・"
            }
        }
        let dateLabel = UILabel(frame: CGRect(x: 15, y: 0, width: CGRectGetWidth(headerView.bounds)-15, height: CGRectGetHeight(headerView.bounds)))
        dateLabel.autoresizingMask = [.FlexibleWidth, .FlexibleHeight]
        dateLabel.font = UIFont(name: "HelveticaNeue-Regular", size: 10)
        dateLabel.textColor = UIColor.darkGrayColor()
        dateLabel.backgroundColor = UIColor.clearColor()
        prefix += sectionDate.string(nil)!
        dateLabel.text = prefix
        
        headerView.addSubview(dateLabel)
        
        return headerView
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        guard eventsByIndexPath[dates![indexPath.section]]!.count > 0 else {
            let cell = tableView.dequeueReusableCellWithIdentifier("NoEvent")!
            return cell
        }
        
        //let cell = tableView.dequeueReusableCellWithIdentifier("DayHeader") as! DayHeaderTableCell
        let cell = tableView.dequeueReusableCellWithIdentifier("EventTableCell") as! EventTableCell
        
        cell.preservesSuperviewLayoutMargins = false
        cell.separatorInset = UIEdgeInsetsZero
        cell.layoutMargins = UIEdgeInsetsZero
        
        let eventItem = eventsByIndexPath[dates![indexPath.section]]![indexPath.row]
        cell.lblEventSubject.text = eventItem.subject
        cell.lblAllDay.hidden = true
        cell.lblStartTime.superview!.hidden = false
        cell.imgAvtar1.hidden = true
        switch indexPath.item {
        case 0:
            cell.lblAllDay.hidden = false
            cell.lblStartTime.superview!.hidden = true
            break
        case 1:
            cell.imgAvtar1.hidden = false
            break
        case 2:
            cell.imgLocationIcon.hidden = false
            cell.lblLocation.hidden = false
            cell.lblLocation.text = "TBD"
            
        default:
            break
        }
        return cell
    }
    
    //MARK: - UITableViewDelegate Methods
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        guard eventsByIndexPath[dates![indexPath.section]]!.count > 0 else {
            //Added to queue to improve performance
            dispatch_async(dispatch_get_main_queue(),{
                self.performSegueWithIdentifier("NewEvent", sender: self)
            })
            return
        }
    }
    
    //MARK: - UIScrollViewDelegate Methods
    func scrollViewDidScroll(scrollView: UIScrollView){
        if listViewInitiatedScroll{
            let sectionIndex = listView.indexPathForCell(listView.visibleCells[0])?.section
            calendarView.selectDate(dates![sectionIndex!])
        }
    }
    
    
    func scrollViewWillBeginDragging(scrollView: UIScrollView){
        listViewInitiatedScroll = true
        
    }
    func scrollViewDidEndDragging(scrollView: UIScrollView, willDecelerate decelerate: Bool){
        listViewInitiatedScroll = decelerate
    }
    func scrollViewWillBeginDecelerating(scrollView: UIScrollView){
        
    }
    
    func scrollViewDidEndDecelerating(scrollView: UIScrollView){
        listViewInitiatedScroll = false
    }
    
    
}


extension EventsController: CalendarViewDelegate,CalendarViewDataSource{
    
    //MARK: - CalendarViewDataSource Methods
    func startDateForCalendar(calendar: CalendarView) -> NSDate? {
        return dates?.first
    }
    
    func endDateForCalendar(calendar: CalendarView) -> NSDate? {
        return dates?.last
    }
    
    //MARK: - CalendarViewDelegate Methods
    func calendar(calendar: CalendarView, didSelectDate selectedDate: NSDate) {
        
        let startDate = gregorian.startOfDayForDate(selectedDate)
        let index = dates!.indexOf(startDate)
        guard index != nil else { return }
        
        todayIndexPath = NSIndexPath(forRow: NSNotFound, inSection: index!)
        listView.scrollToRowAtIndexPath(todayIndexPath!, atScrollPosition: .Top, animated: true)
        print("Did Select: \(selectedDate)")
        
        
    }
    
    func calendar(calendar: CalendarView, didScrollToMonth date: NSDate) {
        
        let startDate = gregorian.startOfDayForDate(date)
        let index = dates!.indexOf(startDate)
        guard index != nil else { return }
        
        todayIndexPath = NSIndexPath(forRow: NSNotFound, inSection: index!)
        listView.scrollToRowAtIndexPath(todayIndexPath!, atScrollPosition: .Top, animated: true)
    }
    
}
